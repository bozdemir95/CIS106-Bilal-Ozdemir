# compute tuition
LastName = (input("Enter your last name " ))
TakenCredits = float(input("Enter the amount of credit hours you taken " ))

# process phase

LabFee = 100
TuitionCreditRate = 250
TotalTuition = TakenCredits * TuitionCreditRate + LabFee

# output phase
print ("Your last name is ", LastName)
print ("and your tuition amount is $", TotalTuition)
