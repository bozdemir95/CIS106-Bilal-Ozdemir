totalGross = 0
counter = 0
print("Do you want to compute a gross pay ( Yes or No ) ")
response = input()
while response == "Yes":
    counter = counter + 1
    print("Enter employees last name ")
    lastName = input()
    print("Enter hours worked ")
    hours = float(input())
    print("Enter rate of pay ")
    rate = float(input())
    if hours > 40:
        grossPay = 40 * rate + (hours - 40) * 1.5 * rate
    else:
        grossPay = hours * rate
    totalGross = totalGross + grossPay
    avgGross = totalGross / counter
    print("Employee " + lastName + " has gross pay of " + str(grossPay))
    print("Do you want to compute a gross pay ( Yes or No ) ")
    response = input()
print("Total Number of Employees " + str(counter))
avg = totalGross / counter
print("Sum of all the gross pay " + str(totalGross))
totalGross = totalGross + grossPay
print("The average pay is " + str(avgGross))
avgGross = totalGross / counter
