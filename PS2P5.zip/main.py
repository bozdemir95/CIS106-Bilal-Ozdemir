# compute tuition

Price = float(input("Enter the price of an item " ))
DiscountPercent = float(input("Enter the discount percent " ))

# process phase

DiscountAmount = Price * DiscountPercent
TotalAmount = Price - DiscountAmount

# output phase
print ("The discount amount is ", DiscountAmount)
print ("and the discounted price of the item is $", TotalAmount)