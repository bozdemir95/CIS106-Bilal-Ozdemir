discAmount = 0
order = 0
totalDiscAmount = 0
print("Do you want to compute extended price ( Yes or No ) ")
response = input()
while response == "Yes":
    order = order + 1
    print("Enter the quantity amount ")
    quantity = float(input())
    print("Enter price of an item ")
    price = float(input())
    extPrice = quantity * price
    if extPrice > 10000.00:
        discAmount = extPrice * .25
    else:
        discAmount = extPrice * .10
    totalAmount = extPrice - discAmount
    totalDiscAmount = totalDiscAmount + discAmount
    print("Order" + str(order) + " has extended price of " + str(extPrice))
    print("Order" + str(order) + " has discount amout of " + str(discAmount))
    print("Order" + str(order) + " has total amount of " + str(totalAmount))
    print("Do you want to compute a extended price ( Yes or No ) ")
    response = input()
print("Sum of all discount amount " + str(totalDiscAmount))
totalDiscAmount = totalDiscAmount + discAmount
