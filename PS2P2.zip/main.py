# compute gross pay
LastName = (input("Enter your last name " ))
Hours = float(input("Enter your how many hours you worked " ))
PayRate = float(input("Enter your pay rate " ))

# process phase

GrossPay = Hours * PayRate

# output phase
print ("Your last name is ", LastName)
print ("And your gross pay is ", GrossPay)
