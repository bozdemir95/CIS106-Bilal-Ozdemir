# compute tip amount
milestravelled = float(input("How many miles travelled? " ))
gallons = float(input("How many gallons used? " ))

# process phase

Mpg = milestravelled / gallons

# output phase
print ("The miles per gallons is", Mpg)
