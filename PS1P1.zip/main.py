#comment my program to do arithmetic
#n1 = 12
#n2 = 10

n1 = float(input("Enter a number"))
n2 = float(input("Enter another number"))

s = n1 + n2
p = n1 * n2
d = n1 - n2

print("Sum is ", s)
print("Difference is ", d)
print("Product is ", p)

