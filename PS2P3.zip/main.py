# compute area and circumference 

Length = float(input("Enter the length of a rectangle " ))
Width = float(input("Enter the width of a rectangle " ))

# process phase

Area = Length * Width
Circumference = 2 * (Length+Width)

# output phase
print ("The area of the rectangle is ", Area)
print ("the circumference of the rectangle is ", Circumference)
