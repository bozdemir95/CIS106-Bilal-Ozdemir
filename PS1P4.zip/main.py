# compute tip amount
amtofmeal = float(input("Enter amount of the meal $" ))

# process phase

tip = amtofmeal * 0.15

# output phase
print ("The amount of the tip is $", tip)
