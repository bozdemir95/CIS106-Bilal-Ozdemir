startv = int(input("Enter a start value"))
stopv = int(input("Enter a stop value"))
incrv = int(input("Enter a increment value"))

while startv <= stopv:
  print(startv)
  startv = startv + incrv
