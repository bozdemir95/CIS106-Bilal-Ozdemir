# Display the extended price

Quantity = float(input("Enter a Quantity " ))
PricePerUnit = float(input("Enter a price per unit " ))

# process phase

ExtendedPrice = Quantity * PricePerUnit

# output phase
print ("The extended price is ", ExtendedPrice)
