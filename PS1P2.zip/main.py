# compute tip amount
LastName = (input("Enter your last name " ))
Ex1 = float(input("Enter your exam 1 score " ))
Ex2 = float(input("Enter your exam 2 score " ))

# process phase

Avg = (Ex1 + Ex2)/ 2

# output phase
print ("Your last name is ", LastName)
print ("Your exam score average is ", Avg)
