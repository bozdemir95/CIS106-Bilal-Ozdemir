Counter = 0
TotalEx1 = 0.0

Response = input("Do you want to computer your average score? (Yes or No)")

while Response == "Yes":
  Counter = Counter + 1
  LastName = input("Enter student last name ")
  Score1 = float(input("Enter exam score 1 "))
  Score2 = float(input("Enter exam score 2 "))
  Avg = (Score1 + Score2) /2 
  print(LastName, " has average of ", Avg)
  TotalEx1 = TotalEx1 + Score1
  Response = input("Do you want to compute your  average score? (Yes or No)")
AvgEx1 = TotalEx1 / Counter
print("Number of students: ", Counter)
print("Average exam score 1 ", AvgEx1)
  